#' @useDynLib diceR, .registration = TRUE
#' @keywords internal
#' @docType package
#' @import ggplot2
#' @importFrom magrittr "%>%"
#' @importFrom purrr "%||%"
#' @importFrom Rcpp sourceCpp
"_PACKAGE"
