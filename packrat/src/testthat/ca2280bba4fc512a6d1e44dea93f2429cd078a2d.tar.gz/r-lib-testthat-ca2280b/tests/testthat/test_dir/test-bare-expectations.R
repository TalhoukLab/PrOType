context("Bare")

expect_that(1, equals(1))
expect_equal(2, 2)
