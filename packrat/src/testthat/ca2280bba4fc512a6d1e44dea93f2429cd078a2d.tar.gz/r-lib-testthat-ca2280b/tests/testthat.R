library(testthat)
options(testthat.use_colours = FALSE)
test_check("testthat")
