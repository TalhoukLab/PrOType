#' @keywords internal
#' @importFrom magrittr "%>%"
#' @importFrom rlang "%||%" ":=" .data
"_PACKAGE"
