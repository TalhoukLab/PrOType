# nanostringr 0.1.2

* sort sample names in HLD and OVD cohorts by numeric order, not lexicographic order

* tidy up code in `HKnorm()`

* use tidy evaluation in `NanostringQC()`

* use `vapply()` over `sapply()` for input checking functions

# nanostringr 0.1.1

* update citation to link to PLOS paper

# nanostringr 0.1.0

* New submission to CRAN accepted on March 15, 2019
