#' @keywords internal
#' @importFrom magrittr "%>%"
#' @importFrom purrr "%||%"
#' @importFrom rlang ":=" .data
"_PACKAGE"
