library(testthat)
library(nanostringr)

test_check("nanostringr")
