# magrittr placeholder
globalVariables(".")
