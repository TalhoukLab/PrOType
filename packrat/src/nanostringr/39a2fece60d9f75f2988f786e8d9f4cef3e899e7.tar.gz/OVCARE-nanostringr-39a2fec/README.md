nanostringr
===========

[![Travis-CI Build Status](https://travis-ci.org/OVCARE/nanostringr.svg?branch=master)](https://travis-ci.org/OVCARE/nanostringr)
[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/OVCARE/nanostringr?branch=master&svg=true)](https://ci.appveyor.com/project/dchiu911/nanostringr)
[![Coverage Status](https://codecov.io/gh/OVCARE/nanostringr/branch/master/graph/badge.svg)](https://codecov.io/gh/OVCARE/nanostringr)

An R Package for quality assurance checking, normalization and batch effects adjustments of NanoString data suitable for single sample processing. This is the companion R package for the paper ["Single-Patient Molecular Testing with NanoString nCounter Data Using a Reference-Based Strategy for Batch Effect Correction"](http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0153844), published in PLOS ONE.


Installation
------------

To install this package, use `devtools`:

``` r
# install.packages(devtools)
devtools::install_github("OVCARE/nanostringr", build_vignettes = TRUE)
```

Dependencies
------------

Please note that the package [CHL26predictor](https://github.com/tinyheero/CHL26predictor) is needed to run the Hodgkin Lymphoma predictive model shown in the vignette.

Overview
--------

To see the full list of exported functions:

``` r
library(nanostringr)
ls("package:nanostringr")
```

A quick overview of the key functions:

-   `NanoStringQC`: Computes quality assurance metrics.
-   `HKnorm`: Performs log (base 2) transformation and normalization to Housekeeping Genes
-   `refMethod`: Performs batch effect correction using the reference-based strategy

A [vignette](http://htmlpreview.github.io/?https://github.com/OVCARE/nanostringr/blob/master/vignettes/Overview.html) that reproduces most of the analyses in the paper is included. The vignettes can be accessed in R using 

``` r
browseVignettes("nanostringr")
```
