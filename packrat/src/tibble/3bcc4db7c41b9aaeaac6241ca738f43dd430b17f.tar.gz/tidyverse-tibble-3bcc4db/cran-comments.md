Bugfix submission.

## Test environments
* local install, R 3.4.3
* ubuntu 12.04 (on travis-ci), R 3.1, R 3.2, R-oldrel, R-release and R-devel
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 notes


## Reverse dependencies

We checked 303 reverse dependencies (300 from CRAN + 3 from BioConductor), comparing R CMD check results across CRAN and dev versions of this package.

* We saw 0 new problems
* We failed to check 0 packages
