"maboost"<-
  function(x,...)UseMethod("maboost")