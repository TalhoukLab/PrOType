#' maboost
#'
#' @name maboost
#' @docType package
NULL
