
# 1.0.0.9000

* Integrated CLI output, using `cli_class` and `cli`

# 1.0.0

First public release.
