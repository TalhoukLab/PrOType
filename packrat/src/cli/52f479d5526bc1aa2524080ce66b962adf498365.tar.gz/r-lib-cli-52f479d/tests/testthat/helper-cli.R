
test_style <- function() {
  list(
    ".testcli" = list(
      h1 = list(
        "font-weight" = "bold",
        "font-style" = "italic",
        "margin-top" = 1,
        "margin-bottom" = 1),
      h2 = list(
        "font-weight" = "bold",
        "margin-top" = 1,
        "margin-bottom" = 1),
      h3 = list(
        "text-decoration" = "underline",
        "margin-top" = 1)
    )
  )
}
