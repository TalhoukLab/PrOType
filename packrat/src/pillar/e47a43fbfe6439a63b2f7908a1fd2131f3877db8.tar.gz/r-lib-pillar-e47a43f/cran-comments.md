Patch update.

## Test environments

* local Ubuntu 17.10 install, R 3.4.4
* Ubuntu 14.04 (on travis-ci), R devel, release, oldrel, 3.2 and 3.1
* win-builder (devel, release, and oldrel)

## R CMD check results

OK

## revdepcheck results

Checked all first- and second-level downstream packages, no regressions found.
