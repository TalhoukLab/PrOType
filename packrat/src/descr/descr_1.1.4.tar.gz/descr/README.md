descr: Descriptive statistics for R
===================================

This is the development version of the R package 'descr'.

