library(testthat)
library(biostatUtil)

test_check("biostatUtil")
