f = "inst/sampleData/usaPolygons.as"

# The idea here is to customize the reading by pre-allocating space.
readArray =
function(type, val) {
#   if(type)
}

# fromJSON(f, )
