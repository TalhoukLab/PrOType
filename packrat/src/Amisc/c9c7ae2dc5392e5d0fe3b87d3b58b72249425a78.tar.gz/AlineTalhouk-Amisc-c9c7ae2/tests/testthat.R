library(testthat)
library(Amisc)

test_check("Amisc")
