# Check times

|   |package   |version | check_time|
|:--|:---------|:-------|----------:|
|3  |readr     |1.0.0   |       19.2|
|5  |tidyverse |1.0.0   |       16.1|
|4  |scales    |0.4.1   |         13|
|2  |haven     |1.0.0   |       12.3|
|1  |feather   |0.3.1   |        9.9|


