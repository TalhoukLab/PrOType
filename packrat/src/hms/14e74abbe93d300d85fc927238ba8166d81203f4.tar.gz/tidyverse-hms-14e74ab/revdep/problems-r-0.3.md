# Setup

## Platform

|setting  |value                        |
|:--------|:----------------------------|
|version  |R version 3.3.2 (2016-10-31) |
|system   |x86_64, linux-gnu            |
|ui       |X11                          |
|language |(EN)                         |
|collate  |en_US.UTF-8                  |
|tz       |Universal                    |
|date     |2016-11-22                   |

## Packages

|package   |*  |version    |date       |source                           |
|:---------|:--|:----------|:----------|:--------------------------------|
|hms       |   |0.2        |2016-06-17 |cran (@0.2)                      |
|lubridate |   |1.6.0      |2016-09-13 |cran (@1.6.0)                    |
|testthat  |   |1.0.2.9000 |2016-08-25 |Github (hadley/testthat@46d15da) |

# Check results

0 packages with problems




