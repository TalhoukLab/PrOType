#' @keywords internal
#' @importFrom hms hms
#' @importFrom R6 R6Class
"_PACKAGE"
