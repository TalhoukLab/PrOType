setGeneric(name = "auc"
            , def = function(object){standardGeneric("auc")}
            )

