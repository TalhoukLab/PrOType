# htmltools

[![Travis-CI Build Status](https://travis-ci.org/rstudio/htmltools.svg)](https://travis-ci.org/rstudio/htmltools)

[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/rstudio/htmltools?branch=master&svg=true)](https://ci.appveyor.com/project/rstudio/htmltools)

Tools for HTML generation and output.
