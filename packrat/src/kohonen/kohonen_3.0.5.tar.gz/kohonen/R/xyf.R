"xyf" <- function(X, Y, ...)
{
  supersom(list(X, Y), ...)
}

