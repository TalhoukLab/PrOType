# ===========================================================================
# File: "zzz.R"
#                        Created: 2010-04-26 08:23:20
#              Last modification: 2011-09-05 17:22:02
# Author: Bernard Desgraupes
# e-mail: <bernard.desgraupes@u-paris10.fr>
# This is part of the R package 'clusterCrit'.
# ===========================================================================

.onLoad <-function (lib, pkg) {
	library.dynam("clusterCrit", pkg, lib)
}
