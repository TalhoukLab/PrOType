## Test environments
* local: R-release (OS X)
* win-builder: R-devel
* travis: R 3.1, R 3.2, R-oldrel, R-release, R-devel

## R CMD check results

0 errors | 0 warnings | 0 notes

## revdepcheck results

We checked 24 reverse dependencies, comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 0 packages
