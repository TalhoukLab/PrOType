# Accept warnings from setOldClass() in R 3.1
add_package_checks(warnings_are_errors = getRversion() > "3.1.3")
