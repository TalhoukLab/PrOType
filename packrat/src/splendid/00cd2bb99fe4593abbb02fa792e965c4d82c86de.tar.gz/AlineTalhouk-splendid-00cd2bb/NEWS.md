# splendid 0.1.0

* Reinstate tidy evaluation semantics after package dependencies updated

* Improved RFE interface

* Added AdaBoost.M1 algorithm

* Added a `NEWS.md` file to track changes to the package.
