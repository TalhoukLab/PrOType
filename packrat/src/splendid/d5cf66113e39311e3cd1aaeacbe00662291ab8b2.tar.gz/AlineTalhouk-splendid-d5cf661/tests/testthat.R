library(testthat)
library(splendid)

test_check("splendid")
