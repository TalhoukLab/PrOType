# splendid 0.1.0

* Extend random seed parameter to more algorithms

* Extended categorical variable conversion to `classification()`

* Reinstate tidy evaluation semantics after package dependencies updated

* Improved RFE interface

* Added AdaBoost.M1 algorithm

* Added a `NEWS.md` file to track changes to the package.
